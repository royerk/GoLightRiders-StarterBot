package main

// Player class, unused yet
type Player struct {
}
